﻿namespace Bilisim.HelloMvc
{
    public class Hayvan
    {
        public void Ses()
        {
            Console.WriteLine("Base class ses metodu");
        }
    }
}
