﻿namespace Bilisim.HelloMvc.Models.ViewModels
{
    public class OgrenciDetayDTO
    {
        public Ogrenci Ogrenci { get; set; }

        public Ogretmen Ogretmen { get; set; }
    }
}
